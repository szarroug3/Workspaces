An interactive tail mode that allows you to filter the tail with
unix pipes and highlight the contents of the tailed file. Works
locally or on remote files using tramp.
